// src/pages/Projects.js
import React from 'react';

const Projects = () => {
  return (
    <div>
      <h2>My Projects</h2>
      <p>List your projects here with descriptions and links.</p>
    </div>
  );
};

export default Projects;
